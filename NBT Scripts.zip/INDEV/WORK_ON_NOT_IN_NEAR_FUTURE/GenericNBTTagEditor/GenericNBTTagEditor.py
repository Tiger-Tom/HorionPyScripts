from tkinter import Tk
def askCopyClip(nbt):
    if input('COPY TEXT TO CLIPBOARD? (Y\\N) >').lower() != 'n':
        r = Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(nbt)
        r.update()
        r.destroy()
#class tagClass:
#    def __init__(self):
#        self.tag = ''
#    def read(self):
#        return self.tag
#    def write(self, toWrite):
#        self.tag = self.tag + toWrite
def generateTag(nbts):
    nbt = '{'
    for i in nbts:
        nbt = nbt + ','
    return nbt + '}'
    
#tagC = tagClass()
import json
nbt = input('ENTER NBT TO EDIT, OR PRESS ENTER WITHOUT ENTERING ANYTHING TO CREATE A NEW NBT >')
if nbt == '':
    nbts = []
else:
    nbts = []
    nbt = nbt[1:-1]
    nbt = nbt.split('{')
