from tkinter import Tk
def askCopyClip(nbt):
    if input('COPY TEXT TO CLIPBOARD? (Y\\N) >').lower() != 'n':
        r = Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(nbt)
        r.update()
        r.destroy()
#{Chested:0b,Color:0b,Color2:0b,FallDistance:0f,FallingBlock:{name:"minecraft:sand",states:{sand_type:"normal"},version:17825806},Fire:0s,Invulnerable:0b,IsAngry:0b,IsAutonomous:0b,IsBaby:0b,IsEating:0b,IsGliding:0b,IsGlobal:0b,IsIllagerCaptain:0b,IsOrphaned:0b,IsRoaring:0b,IsScared:0b,IsStunned:0b,IsSwimming:0b,IsTamed:0b,IsTrusting:0b,LastDimensionId:0,LootDropped:0b,MarkVariant:0,Motion:[0f,0.36298f,0f],OnGround:0b,OwnerNew:-1l,PortalCooldown:0,Pos:[1.5f,3.35101f,42.5f],Rotation:[0f,0f],Saddled:0b,Sheared:0b,ShowBottom:0b,Sitting:0b,SkinID:0,Strength:0,StrengthMax:0,Time:33b,UniqueID:-270582939635l,Variant:4430,definitions:[],identifier:"minecraft:falling_block"}
#blockID = input('ENTER BLOCK ID (WITHOUT "minecraft:" PREFIX) >')
#noAI = input('WILL BLOCK BE PLACED WHEN IT HITS THE GROUND? (Y\\N) >')
#if noAI.lower() != 'y':
#    noAI = '0'
#else:
#    noAI = '1'
#grav = input('WILL BLOCK HAVE GRAVITY? (Y\\N) >')
#if grav.lower() != 'n':
#    grav = '0'
#else:
#    grav = '1'
command = ''
custName = ''
executeOnFirstTick = '10'
conditional = '10'
needsRedstone = '10'
lpCommandMode = '10'
commandBlock = 'Command:"'+command+'",CustomName:"'+custName+'",ExecuteOnFirstTick:'+executeOnFirstTick+'b,LPCommandMode:'+lpCommandMode+',LPCondionalMode:'+conditional+'b,LPRedstoneMode:'+needsRedstone+'b,TickDelay:'+tickDelay+',Version:12,id:"CommandBlock"'
{Command:"/test",CustomName:"",ExecuteOnFirstTick:0b,LPCommandMode:0,LPCondionalMode:0b,LPRedstoneMode:0b,LastExecution:0l,LastOutput:"commands.generic.unknown",LastOutputParams:["test"],SuccessCount:0,TickDelay:0,TrackOutput:1b,Version:12,auto:0b,conditionMet:0b,conditionalMode:0b,display:{Lore:["(+DATA)"]},powered:0b}
{Command:"/test",CustomName:"",ExecuteOnFirstTick:0b,LPCommandMode:0,LPCondionalMode:0b,LPRedstoneMode:0b,LastExecution:0l,LastOutput:"commands.generic.unknown",LastOutputParams:["test"],SuccessCount:0,TickDelay:0,TrackOutput:1b,Version:12,auto:1b,conditionMet:0b,id:"CommandBlock",isMovable:1b,powered:0b,x:69,y:4,z:-40}
{Command:"/test",CustomName:"",ExecuteOnFirstTick:1b,LPCommandMode:1,LPCondionalMode:0b,LPRedstoneMode:0b,LastExecution:1386268l,LastOutput:"commands.generic.unknown",LastOutputParams:["test"],SuccessCount:0,TickDelay:0,TrackOutput:1b,Version:12,auto:1b,conditionMet:1b,id:"CommandBlock",isMovable:1b,powered:0b,x:69,y:4,z:-40}
nbt = '{Items:[{Block:{name:"minecraft:lever",states:{lever_direction:"down_east_west",open_bit:0b},version:17760256},Count:64b,Damage:0s,Name:"minecraft:lever",Slot:1b},{Count:1b,Damage:5s,Name:"minecraft:bucket",Slot:2b,tag:{EntityType:66,display:{Name:"Bucket Of Falling '+blockIDName+'"},FallingBlock:{name:"minecraft:'+blockID+'",version:17825806},IsGlobal:1b,NoAI:'+noAI+'b,NoGravity:'+grav+'b,CurrentTickCount:0,TrackOutput:0b,definitions:["+minecraft:falling_block"],identifier:"minecraft:falling_block"}}]}'
print ('TO GET COMMAND, USE [.nbt write] WHILE HOLDING A STORAGE ITEM (CHEST, FURNACE, DISPENSER\\DROPPER, ETC. THEN TAKE OUT THE PUFFERFISH FROM THE BLOCK AND PLACE IT DOWN TO SPAWN THE MOB\\ENTITY.')
print (nbt)
askCopyClip(nbt)
