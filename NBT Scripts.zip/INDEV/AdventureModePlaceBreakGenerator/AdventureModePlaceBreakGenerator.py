from tkinter import Tk
def askCopyClip(nbt):
    if input('COPY TEXT TO CLIPBOARD? (Y\\N) >').lower() != 'n':
        r = Tk()
        r.withdraw()
        r.clipboard_clear()
        r.clipboard_append(nbt)
        r.update()
        r.destroy()
def makeCanDestroy(canDestroys):
    nbt = 'CanDestroy:['
    for i in canDestroys:
        nbt = nbt + '"' + i + '",'
    nbt = nbt + ']'
    return nbt
def makeCanPlaceOn(canPlaceOns):
    nbt = 'CanPlaceOn:['
    for i in canPlaceOns:
        nbt = nbt + '"' + i + '",'
    nbt = nbt + ']'
    return nbt
def make(canPlaceOns, canDestroys):
    nbt = '{'
    nbtCanDestroys = makeCanDestroy(canDestroys)
    nbtCanPlaceOn = makeCanPlaceOn(canPlaceOns)
    nbt = nbt + nbtCanPlaceOn + ',' + nbtCanDestroys + '}'
    return nbt
canDest = []
canPlac = []
print ('PRESS CTRL+C WHEN YOU ARE DONE ENTERING BLOCKS THAT ITEM CAN DESTROY')
while True:
    try:
        block = input('ENTER BLOCK THAT THAT ITEM CAN DESTROY >')
        if not 'minecraft:' in block:
            block = 'minecraft:'+block
        canDest.append(block)
    except KeyboardInterrupt:
        break
print ('PRESS CTRL+C WHEN YOU ARE DONE ENTERING BLOCKS THAT ITEM CAN BE PLACED ON')
while True:
    try:
        block = input('ENTER BLOCK THAT BLOCK CAN BE PLACED ON >')
        if not 'minecraft:' in block:
            block = 'minecraft:'+block
        canPlac.append(block)
    except KeyboardInterrupt:
        break
nbt = make(canPlac, canDest)
print ('USE [.nbt write] WHILE HOLDING WHATEVER ITEM YOU WANT TO WRITE TO')
print (nbt)
askCopyClip(nbt)
