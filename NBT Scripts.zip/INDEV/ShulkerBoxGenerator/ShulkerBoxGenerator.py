import tkinter
import webbrowser
from functools import partial
colors = {
    'Black': '0',
    'Red': '1',
    'Green': '2',
    'Brown': '3',
    'Blue': '4',
    'Purple': '5',
    'Cyan': '6',
    'Light Gray': '7',
    'Gray': '8',
    'Pink': '9',
    'Lime': '10',
    'Yellow': '11',
    'Light Blue': '12',
    'Magenta': '13',
    'Orange': '14',
    'White': '15',
}

#BASIC CONTROLS
def bringToFront(root):
    root.lift()
    root.attributes('-topmost', True)

#SHULKER
class Shulker():
    def __init__(self):
        self.color = None
        self.name = None
        self.lore = None
        self.inventory = []
        self.emptyAllSlots()
    def emptyAllSlots(self):
        i = 0
        while i < 27:
            try:
                self.inventory[i] = {}
            except:
                self.inventory.append({})
            i = i + 1
    def isSlotEmpty(self, slot):
        return self.inventory[slot] == {}
    def addItem(self, item, slot):
        self.inventory[slot] = item

#WINDOWS
##SETTING UP WINDOW
def setupWindow(shulker):
    root = tkinter.Tk()
    root.title('Setup Shulker Box')
    color = tkinter.StringVar(root)
    color.set('Black')
    ColorOptMenu = tkinter.OptionMenu(root, color, 'Black', 'Red', 'Green', 'Brown', 'Blue', 'Purple', 'Cyan', 'Light Gray', 'Gray', 'Pink', 'Lime', 'Yellow', 'Light Blue', 'Magenta', 'Orange', 'White').grid(row=0)
    tkinter.Label(root, text='Shulker Box Name').grid(row=1)
    tkinter.Label(root, text='Shulker Box Lore').grid(row=2)
    loreText = tkinter.Text(root, height=3)
    loreText.grid(row=2)
    inpNam = tkinter.Entry(root)
    inpNam.grid(row=1)
    tkinter.Button(root, text='Done', command=root.quit).grid(row=3, sticky=tkinter.W, pady=4)
    bringToFront(root)
    root.mainloop()
    shulker.color = color.get()
    shulker.name = inpNam.get()
    shulker.lore = loreText.get('1.0', 'end-1c').split('\n')
    
##MAIN WINDOW
def mainWindow(shulker):
    root = tkinter.Tk()
    root.title('Shulker Box')
    items = shulker.inventory
    buttons = []
    for i in range(len(items)):
        button = {}
        if items[i] == {}:
            empty = True
            button['bg'] = 'red2'
            amount = '00'
            ench = False
            button['fg'] = 'gray1'
            unbrk = False
        else:
            button['bg'] = 'snow'
            if items[i]['ench'] != {}:
                ench = True
                button['fg'] = 'MediumOrchid2'
            else:
                ench = False
                button['fg'] = 'gray1'
            if items[i]['Count'] < 10:
                amount = '0'+str(items[i]['Count'])
            else:
                amount = str(items[i]['Count'])
        slot = i+1
        if slot < 10:
            slot = '0' + str(slot)
        else:
            slot = str(slot)
        button['text'] = slot + ' (*'+amount+')'
        button['width'] = 6
        button['height'] = 1
        button['command'] = partial(mainWindowFunction1, [root, i, shulker])
        buttons.append(button)
    num_ = 0
    col_ = 0
    row_ = 0
    while num_ < len(buttons):
        button = buttons[num_]
        tkinter.Button(root, bg=button['bg'], fg=button['fg'], text=button['text'], command=button['command']).grid(row=row_, column=col_)
        col_ = col_ + 1
        if col_ > 8:
            col_ = 0
            row_ = row_ + 1
        num_ = num_ + 1
###MAIN WINDOW FUNCTION 1
def mainWindowFunction1(args):
    root,slot,shulker = args
    root.destroy()
    addItemWindow(slot, shulker)
    mainWindow(shulker)
##ADD ITEM WINDOW
def addItemWindow(slot, shulker):
    dSlot = str(slot + 1)
    ench = {}
    root = tkinter.Tk()
    tkinter.Label(root, text='Item For Slot '+dSlot).grid(row=0)
    tkinter.Label(root, text='Damage Value').grid(row=1)
    tkinter.Label(root, text='Amount').grid(row=2)
    tkinter.Label(root, text='Custom Name').grid(row=3)
    tkinter.Label(root, text='Lore').grid(row=4)
    tkinter.Label(root, text='Enchantments').grid(row=5)
    loreText = tkinter.Text(root, height=3)
    loreText.grid(row=4)
    inpID = tkinter.Entry(root)
    inpID.grid(row=0)
    inpDm = tkinter.Entry(root)
    inpDm.grid(row=1)
    inpAm = tkinter.Entry(root)
    inpAm.grid(row=2)
    inpCN = tkinter.Entry(root)
    inpCN.grid(row=3)
    tkinter.Button(root, text='Add Enchantments', command=enchantmentWindow).grid(row=5, sticky=tkinter.W, pady=4)
    tkinter.Button(root, text='Done', command=root.quit).grid(row=6, sticky=tkinter.W, pady=4)
    root.mainloop()
    itID = inpID.get()
    damg = inpDm.get()
    amnt = inpAm.get()
    cstm = inpCN.get()
    lore = loreText.get('1.0', 'end-1c').split('\n')
    item = {}
    item['Name'] = itID
    item['Count'] = amnt
    item['Damage'] = damg
    item['Slot'] = slot
    item['Display'] = {'Name': cstm, 'lore': lore}
    item['ench'] = ench
    item['Unbreakable'] = unbreakable
    shulker[slot] = item
    root.destroy()
###ENCHANTMENT WINDOW
flag0 = False
def enchantmentWindow():
    global flag0
    flag0 = False
    currentEnchants = []
    while True:
        if flag0 == False:
            root = tkinter.Tk()
            root.title('Set Item Enchantment')
        else:
            for i in root.winfo_children():
                i.destroy()
        flag0 = False
        enchs = currentEnchants
        tkinter.Label(root, text='Use Numerical Enchantment IDs').grid(row=0)
        tkinter.Button(root, text='List Of Enchantment IDs', command=partial(webbrowser.open_new, 'https://minecraftbedrock.fandom.com/wiki/Enchanting/List_of_Enchantments')).grid(row=1, sticky=tkinter.W, pady=4)
        tkinter.Label(root, text='Num. ID').grid(row=2, column=0)
        tkinter.Label(root, text='Level').grid(row=2, column=1)
        table = []
        currentRows = len(enchs)+3
        for i in range(len(enchs)):
            line = []
            tempList = [enchs[i]['id'], enchs[i]['lvl']]
            for j in range(2):
                e = tkinter.Entry(root, width=6)
                e.grid(row=i+3, column=j)
                e.insert(tkinter.END, tempList[j])
                line.append(e)
            table.append(line)
        tkinter.Button(root, text='Add Enchantment', command=partial(enchWindowFunc1, root)).grid(row=currentRows+1, sticky=tkinter.W, pady=4)
        currentRows = currentRows + 1
        tkinter.Button(root, text='Done', command=root.quit)
        
def begin():
    shulker = Shulker()
    setupWindow(shulker)
    mainWindow(shulker)
