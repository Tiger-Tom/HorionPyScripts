import tkinter
import json
import webbrowser
from functools import partial
import inspect

debugFlag = False

colors = {
    'Black': '0',
    'Red': '1',
    'Green': '2',
    'Brown': '3',
    'Blue': '4',
    'Purple': '5',
    'Cyan': '6',
    'Light Gray': '7',
    'Gray': '8',
    'Pink': '9',
    'Lime': '10',
    'Yellow': '11',
    'Light Blue': '12',
    'Magenta': '13',
    'Orange': '14',
    'White': '15',
}
class DebugTextClass():
    def __init__(self):
        self.texts = []
        self.most_recent = None
    def write(self, text):
        self.texts.append(text)
        self.most_recent = text
    def read(self):
        return self.texts
    def getRecent(self):
        return self.most_recent
    def reset(self):
        self.texts = []
        self.most_recent = None
DebugText = DebugTextClass()
def debug(text):
    global DebugText
    global debugFlag
    if debugFlag == True:
        print (text)
    DebugText.write(text)
class Shulker():
    def __init__(self, color=None, name=None, lore=None):
        self.color = None
        self.name = None
        self.lore = None
        self.inventory = []
        self.emptyAllSlots()
    def emptyAllSlots(self, num=27):
        i = 0
        while i < num:
            try:
                self.inventory[i] = {}
            except:
                self.inventory.append({})
            i = i + 1
    def findFirstEmptySlot(self):
        slotNum = -1
        i = 0
        while i < len(self.inventory):
            if self.inventory[i] == {}:
                slotNum = i
                break
            i = i + 1
        return slotNum
    def isSlotEmpty(self, slot):
        return self.inventory[slot] == {}
    def addItem(self, item, slot=None):
        if slot == None:
            slot = self.findFirstEmptySlot()
        if slot == -1:
            print ('SHULKER BOX IS FULL') ########### CHANGE TO TKINTER OUTPUT
            return False
        else:
            self.inventory[slot] = item
            return True
class shWindow():
    def __init__(self, shulker):
        self.shulker = shulker
        self.currentlyWorkingItemEnchants = []
        self.flag0 = False
        self.currentFlag0Root = None
        self.flag1 = False
        self.currentFlag1Root = None
        self.currentSlot = None
        self.flag2 = False
    def setupWindow(self):
        root = tkinter.Tk()
        root.title('Setup Shulker Box')
        #tkinter.Label(root, text='Shulker Box Color').grid(row=0)
        color = tkinter.StringVar(root)
        color.set('Black')
        ColorOptMenu = tkinter.OptionMenu(root, color, 'Black', 'Red', 'Green', 'Brown', 'Blue', 'Purple', 'Cyan', 'Light Gray', 'Gray', 'Pink', 'Lime', 'Yellow', 'Light Blue', 'Magenta', 'Orange', 'White').grid(row=0)
        tkinter.Label(root, text='Shulker Box Name').grid(row=1)
        tkinter.Label(root, text='Shulker Box Lore 1').grid(row=2)
        tkinter.Label(root, text='Shulker Box Lore 2').grid(row=3)
        tkinter.Label(root, text='Shulker Box Lore 3').grid(row=4)
        inpNam = tkinter.Entry(root)
        inpNam.grid(row=1, column=1)
        inpLor1 = tkinter.Entry(root)
        inpLor1.grid(row=2, column=1)
        inpLor2 = tkinter.Entry(root)
        inpLor2.grid(row=3, column=1)
        inpLor3 = tkinter.Entry(root)
        inpLor3.grid(row=4, column=1)
        tkinter.Button(root, text='Done', command=root.quit).grid(row=5, sticky=tkinter.W, pady=4)
        root.lift()
        root.attributes('-topmost', True)
        root.mainloop()
        self.shulker.color = color.get()
        self.shulker.name = inpNam.get()
        lor1 = inpLor1.get()
        lor2 = inpLor2.get()
        lor3 = inpLor3.get()
        lore = []
        if lor3 != '':
            lore = [lor1, lor2, lor3]
        elif lor2 != '':
            lore = [lor1, lor2]
        elif lor1 != '':
            lore = [lor1]
        else:
            lore = []
        self.shulker.lore = lore
        root.destroy()
    def mainShulkerWindow(self):
        self.flag1 = False
        self.currentSlot = None
        while True:
            if self.flag1 == False:
                root = tkinter.Tk()
                root.title('Shulker Box')
                self.currentFlag1Root = root
                self.currentSlot = None
            else:
                for i in root.winfo_children():
                    i.destroy()
            items = self.shulker.inventory
            keys_ = {
                '#': 'Empty',
                '@': 'Enchanted',
                '$X': 'Has Amount "X"'
            }
            itemsDisplays = {}
            slot_ = 0
            for i in items:
                itemLabels = []
                if i == {}:
                    itemLabels.append('#')
                else:
                    if i['ench'] != {}:
                        itemLabels.append('@')
                    if i['Count'] > 1:
                        itemLabels.append('$'+str(i['Count']))
                itemsDisplays[slot_] = itemLabels
                slot_ = slot_ + 1
            itemButtons1 = []
            for i in range(len(itemsDisplays)):
                if '@' in itemsDisplays[i]:
                    isEnch = True
                else:
                    isEnch = False
                if '#' in itemsDisplays[i]:
                    isEmpty = True
                    num = None
                else:
                    isEmpty = False
                    if '$' in itemsDisplays[i]:
                        num1 = itemsDisplays[i].split('$')
                        num = num1[1]
                    else:
                        num = None
                button = generateItemButton(i, num, isEnch, partial(self.setFlag1, i))
                itemButtons1.append(button)
            itemButtons = []
            col = 1
            row_ = 1
            num_ = 0
            while num_ < len(self.shulker.inventory):
                button = itemButtons1[num_]
                itemButtons.append(tkinter.Button(root, bg=button['bg'], fg=button['fg'], text=button['text'], width=button['width'], height=button['height'], command=button['command']))
                itemButtons[num_].grid(row=row_, column=col)
                col = col + 1
                if col > 9:
                    col = 1
                    row_ = row_ + 1
                num_ = num_ + 1
            if self.currentSlot != None:
                currentB = itemButtons[self.currentSlot-1]
                currentI = self.shulker.inventory[i]
                if currentI != {}:
                    loreText = ''
                    for i in currentI['Display']['lore']:
                        loreText = loreText+'\n   '+i
                    if currentI['ench'] != {}:
                        enchd = 'Yes'
                    else:
                        enchd = 'No'
                    if currentI['Unbreakable'] == True:
                        unbrkT = 'Yes'
                    else:
                        unbrkT = 'No'
                    currentT = 'Item '+str(self.currentSlot+1)+':\n ID:'+currentI['Name']+'\n Amount:'+str(currentI['Count'])+'\n Damage Value:'+str(currentI['Damage'])+'\n Display:\n  Custom Name: '+currentI['Display']['Name']+'\n  Lore:\n   '+loreText+'\n Enchanted: '+enchd+'\n Unbreakable: '+unbrkT
                else:
                    currentT = 'Slot '+str(self.currentSlot+1)+':\n Empty'
            else:
                currentT = 'No Item Selected'
            text = tkinter.Text(root)
            text.grid(row=4)
            text.insert(tkinter.END, currentT)
            if self.currentSlot != None:
                #itemButtons[self.currentSlot]
                editButtonState = tkinter.NORMAL
                editButtonText = 'Edit Item In Slot '+str(self.currentSlot)
                editButtonCommand = partial(self.addItemWindow, self.currentSlot-1)
            else:
                editButtonState = tkinter.DISABLED
                editButtonText = 'No Item Selected'
                editButtonCommand = None
            tkinter.Button(root, text=editButtonText, command=editButtonCommand, state=editButtonState).grid(row=5, sticky=tkinter.W, pady=4)
            tkinter.Button(root, text='Done', command=root.quit).grid(row=6, sticky=tkinter.W, pady=4)
            root.lift()
            root.attributes('-topmost', True)
            root.mainloop()
            if self.flag1 == True:
                slot = self.currentSlot
                self.addItemWindow(slot-1)
            else:
                root.destroy()
                break
    def addItemWindow(self, slot):
        root = tkinter.Tk()
        root.title('Set Item Of Slot '+str(slot+2))
        self.currentlyWorkingItemEnchants = []
        tkinter.Label(root, text='Item For Slot '+str(slot+2)).grid(row=0)
        tkinter.Label(root, text='Damage Value').grid(row=1)
        tkinter.Label(root, text='Amount').grid(row=2)
        tkinter.Label(root, text='Custom Name').grid(row=3)
        tkinter.Label(root, text='Custom Lore 1').grid(row=4)
        tkinter.Label(root, text='Custom Lore 2').grid(row=5)
        tkinter.Label(root, text='Custom Lore 3').grid(row=6)
        #tkinter.Label(root, text='Unbreakable').grid(row=7)
        unbreakable = tkinter.IntVar()
        tkinter.Checkbutton(root, text='Unbreakable', variable=unbreakable).grid(row=7)
        inpID = tkinter.Entry(root)
        inpID.grid(row=0, column=1)
        inpDamg = tkinter.Entry(root)
        inpDamg.grid(row=1, column=1)
        inpCoun = tkinter.Entry(root)
        inpCoun.grid(row=2, column=1)
        inpName = tkinter.Entry(root)
        inpName.grid(row=3, column=1)
        inpLor1 = tkinter.Entry(root)
        inpLor1.grid(row=4, column=1)
        inpLor2 = tkinter.Entry(root)
        inpLor2.grid(row=5, column=1)
        inpLor3 = tkinter.Entry(root)
        inpLor3.grid(row=6, column=1)
        tkinter.Button(root, text='Add Enchantments', command=self.enchantmentWindow).grid(row=8, sticky=tkinter.W, pady=2)
        tkinter.Button(root, text='Done', command=root.quit).grid(row=9, sticky=tkinter.W, pady=4)
        root.lift()
        root.attributes('-topmost', True)
        root.mainloop()
        itemName = inpName.get()
        itemDamage = inpDamg.get()
        try:
            itemDamage = int(itemDamage)
        except TypeError:
            itemDamage = 0
        itemCount = inpCoun.get()
        try:
            itemCount = int(itemCount)
        except TypeError:
            itemCount = 1
        itemCustName = inpName.get()
        lor1 = inpLor1.get()
        lor2 = inpLor2.get()
        lor3 = inpLor3.get()
        lore = []
        if lor3 != '':
            itemLore = [lor1, lor2, lor3]
        elif lor2 != '':
            itemLore = [lor1, lor2]
        elif lor1 != '':
            itemLore = [lor1]
        else:
            itemLore = []
        itemUnbreakable = unbreakable.get()
        item = makeItem(itemName, itemCount, itemDamage, slot, itemCustName, itemLore, self.currentlyWorkingItemEnchants, itemUnbreakable, {})
        self.shulker.inventory[slot+1] = item
        root.destroy()
        self.currentFlag1Root.quit()
        return item
    def enchantmentWindow(self):
        self.flag0 = False ##WINDOW REFRESH
        while True:
            if self.flag0 == False: ##WINDOW REFRESH [
                root = tkinter.Tk()
                self.currentFlag0Root = root
                root.title('Set Item Enchantments')
            else:
                for i in root.winfo_children():
                    i.destroy()
                
            self.flag0 = False ## ]
            enchs = self.currentlyWorkingItemEnchants
            tkinter.Label(root, text='IDs can be found at').grid(row=0)
            tkinter.Button(root, text='Open Wiki', command=openEnchWiki).grid(row=1, sticky=tkinter.W, pady=4)
            #t = tkinter.Text(root, width=len('https://minecraftbedrock.fandom.com/'), height=2)
            #t.grid(row=1, column=1)
            #t.insert(tkinter.INSERT, 'https://minecraftbedrock.fandom.com/')
            #t.insert(tkinter.END, '\nwiki/Enchanting/List_of_Enchantments')
            #tkinter.Label(root, text='https://minecraftbedrock.fandom.com/wiki/Enchanting/List_of_Enchantments').grid(row=2)
            tkinter.Label(root, text='Num. ID').grid(row=2, column=0)
            tkinter.Label(root, text='Level').grid(row=2, column=1)
            table = []
            currentRows = len(enchs)+3
            for i in range(len(enchs)):
                line = []
                tempList = enchs[i]['id'], enchs[i]['lvl']
                for j in range(2):
                    e = tkinter.Entry(root, width=8)
                    e.grid(row=i+3, column=j)
                    e.insert(tkinter.END, tempList[j])
                    line.append(e)
                table.append(line)
            tkinter.Button(root, text='Add Enchantment', command=self.setFlag0).grid(row=currentRows+1, sticky=tkinter.W, pady=4) ##WINDOW REFRESH
            currentRows = currentRows + 1
            tkinter.Button(root, text='Done', command=root.quit).grid(row=currentRows+1, sticky=tkinter.W, pady=4)
            root.lift()
            root.attributes('-topmost', True)
            root.mainloop()
            enchs = []
            for i in table:
                try:
                    eID = int(i[0].get())
                    lvl = int(i[1].get())
                    ench = {'id': eID, 'lvl': lvl}
                    enchs.append(ench)
                except:
                    pass
            if self.flag0 == True: ##WINDOW REFRESH [
                enchs.append({'id': 'ID', 'lvl': 'LEVEL'})
                self.currentlyWorkingItemEnchants = enchs
            else:
                root.destroy()
                break ## ]
        self.currentlyWorkingItemEnchants = enchs
    def setFlag0(self):
        if self.flag0 == False:
            self.flag0 = True
            debug('SET FLAG 0')
            debug('QUIT CURRENT ROOT USING FLAG 0 (ROOT: ['+str(self.currentFlag0Root)+'])')
            #print ('SET FLAG 0')
            self.currentFlag0Root.quit()
    def setFlag1(self, slot):
        if self.flag1 == False:
            self.flag1 = True
            self.currentSlot = slot
            debug('SET FLAG 1')
            debug('QUIT CURRENT ROOT USING FLAG 1 (ROOT: ['+str(self.currentFlag1Root)+'])')
            debug('SET VARIABLE "self.currentSlot" TO '+str(slot))
            self.currentFlag1Root.quit()
    def setFlag2(self):
        if self.flag2 == False:
            self.flag2 = True
            debug('SET FLAG 2')
            debug('QUIT CURRENT ROOT USING FLAG 1 (ROOT: ['+str(self.currentFlag1Root)+'])')
            self.currentFlag1Root.quit()

def generateItemButton(slot, num, ench, comMethd):
    button = {}
    slot = slot + 1
    if slot < 10:
        slot = '0'+str(slot)
    slot = str(slot)
    if num == None:
        empty = True
        num = 0
    if num < 10:
        num = '0'+str(num)
    num = str(num)
    regularFG = 'gray1'
    enchColor = 'MediumOrchid2'
    regularBG = 'snow'
    emptyBG = 'red2'
    if ench == True:
        textColor = enchColor
    else:
        textColor = regularFG
    if empty == True:
        backgroundColor = emptyBG
    else:
        backgroundColor = regularBG
    button['bg'] = backgroundColor
    button['fg'] = textColor
    button['text'] = '['+slot+' *'+num+']'
    button['width'] = 6
    button['height'] = 1
    button['command'] = comMethd
    #tkinter.Button(root, bg=button['bg'], fg=button['fg'], text=button['text'], width=button['width'], height=button['height'], command=button['command'])   
    return button
def openEnchWiki():
    webbrowser.open_new('https://minecraftbedrock.fandom.com/wiki/Enchanting/List_of_Enchantments')
def makeItem(itemName, amount, damage, slot, custom_name, lore, enchantments, unbreakable, nbt):
    #ITEMNAME:STRING  AMOUNT:INT  SLOT:INT  CUSTOM_NAME:STRING  LORE:LIST OF STRINGS  ENCHANTMENTS:LIST OF DICTIONARIES  UNBREAKABLE:BOOLEAN  NBT:DICTIONARYS
    item = {}
    tag = {}
    #ITEM ID
    if not 'minecraft:' in itemName:
        itemName = 'minecraft:' + itemName
    item['Name'] = itemName
    #AMOUNT
    item['Count'] = amount
    #DAMAGE
    item['Damage'] = damage
    #SLOT
    item['Slot'] = slot
    #NAME ; LORE
    item['Display'] = {'Name': custom_name, 'lore': lore}
    #ENCHANTMENTS
    item['ench'] = enchantments
    #UNBREAKABLE
    item['Unbreakable'] = unbreakable
    #NBT
    for i in nbt:
        item[i] = nbt[i]
    return item
if input('Run? (Y/n) >').lower() != 'n':
    #nam = input('Enter name >')
    #color = input('Enter color (
    shulker = Shulker()
    shWin = shWindow(shulker)
    shWin.setupWindow()
    shWin.mainShulkerWindow()
