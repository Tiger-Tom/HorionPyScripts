import tkinter
from functools import partial
class numberButtonSelect():
    def __init__(self):
        self.flag0 = False
        self.currentSlot = None
    def testPrint(self, toPrint):
        print (toPrint)
    def numberButtonSelect(self):
        root = tkinter.Tk()
        buttons = []
        for i in range(27):
            buttons.append({'text': str(i), 'command': partial(print, str(i))})
        col_ = 0
        row_ = 0
        num_ = 0
        while num_ < len(buttons):
            button = buttons[num_]
            tkinter.Button(root, text=button['text'], command=button['command']).grid(row=row_, column=col_)
            col_ = col_ + 1
            if col_ > 8:
                col_ = 0
                row_ = row_ + 1
            num_ = num_ + 1
        root.mainloop()
